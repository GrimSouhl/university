public class Metodo {

	//OPERACIONES:
	public static final String SUMA = "$suma";
	public static final String RESTA = "$resta";
	public static final String PRODUCTO = "$producto";
	public static final String DIVISION = "$division";
	public static final String MODULO = "$modulo";
	//EXAMEN:
	public static final String DESPDERECHA = "$despder";
	public static final String DESPIQUIERDA = "$despizq";
	public static final String  REPEATTIMES = "$repeartimes";
	public static final String  DESPDERECHA3 = "der3";
	public static final String  DESPIQUIERDA3 = "iz3";
	//- -- ++ 
	public static final String OPUESTO = "$opuesto";
	public static final String SIGUIENTE = "$siguiente";
	public static final String ANTERIOR = "$anterior";
	
	//LOGICOS
	public static final String AND = "$and";
	public static final String OR = "$or";
	public static final String NOT = "$not";
	public static final String IMPLICACION = "$implica";
	

	//COMPARACIONES
	public static final String IGUAL = "$igual";
	public static final String DISTINTO = "$distinto";
	public static final String MENOR = "$menor";
	public static final String MENOR_IGUAL = "$menor_igual";
	public static final String MAYOR = "$mayor";
	public static final String MAYOR_IGUAL = "$mayor_igual";
	
	//CASTING
	public static final String CAST = "$cast";
	
	//CREACIONES
	public static final String CREAR_LITERAL = "$crear_literal";
	public static final String CREAR_VARIABLE = "$crear_variable";

	//ASIG
	public static final String ASIGNAR = "$asignar";
	
	//PRINT
	public static final String MOSTRAR = "$mostrar";
	
	//PONER ETIQ
	public static final String PONER_ETQ = "$put_etq";  	
	public static final String SALTAR_ETQ = "$skip_etq";
   	
	
}