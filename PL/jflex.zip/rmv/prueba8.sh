nombre=Pepe
echo "nombre=$nombre"
