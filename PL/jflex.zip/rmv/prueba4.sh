Hola=Hola;Adios=adios;
_nombres_2="Jose; Luis;"
echo $Hola y $Adios, $_nombres_2
