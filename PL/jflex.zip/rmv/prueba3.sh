nombre="Pepe Luis"
apellidos="Rodriguez Zapatero"
echo Hola $nombre $apellidos
