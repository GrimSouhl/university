  nombre=Pepe; apellidos=Rodriguez
echo Hola $nombre $apellidos
