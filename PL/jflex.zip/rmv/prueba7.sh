v1=1; v2=2; v3=3;
numero=$v1$v2$v3=100*$v1+10*$v2+$v3
echo $numero
