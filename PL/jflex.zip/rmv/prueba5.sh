saludo=Hola; frase="$saludo mundo"
echo $frase
