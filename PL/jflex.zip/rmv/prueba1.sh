nombre=Ricardo
echo $nombre
