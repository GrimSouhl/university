class Prueba4 {
	public static void main(String argv[]) {
		String _ = "Uno";
		System.out.println(_);
	}
}
