class Prueba14 {
	public static void main(String argv[]) {
		String st1 = "Uno\n";
	    System.out.println(st1);		   
		 	   st1 = st1 + "Dos;";
        System.out.println(st1);		   
               st1 = st1 + "\"Tres\"";
        System.out.println(st1);		   
	}
}
