class Prueba11_rmj {
	public static void main(String argv[]) {
		 
		System.out.println("\\Uno\nDos\n\\");
	}
}
