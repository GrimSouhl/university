class Prueba4_rmj {
	public static void main(String argv[]) {
		 
		System.out.println("Uno");
	}
}
