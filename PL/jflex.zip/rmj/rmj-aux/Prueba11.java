class Prueba11 {
	public static void main(String argv[]) {
		String variable = "\\Uno\nDos\n\\";
		System.out.println(variable);
	}
}
