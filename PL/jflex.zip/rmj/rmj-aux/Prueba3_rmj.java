class Prueba3_rmj {
	public static void main(String parametros[]) {
		System.out.println("parametros");
	}
}
