class Prueba10 {
	public static void main(String argv[]) {
		System.out.println("\"Uno\" " + " \"Dos\"");
	}
}
