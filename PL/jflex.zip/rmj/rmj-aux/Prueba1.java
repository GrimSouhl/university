class Prueba1 {
	public static void main(String argv[]) {
		System.out.println("Uno"+"Dos");
	}
}
