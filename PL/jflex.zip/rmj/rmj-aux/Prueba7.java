class Prueba7 {
	public static void main(String argv[]) {
		String var1 = "Uno+"     +  "Dos+"   ;
		String var2 = "Cuatro+"  +  "Cinco"  ;
		System.out.println(var1+  "Tres"  +  "+"  +  var2);
	}
}
