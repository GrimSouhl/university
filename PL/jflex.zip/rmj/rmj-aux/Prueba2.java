class Prueba2 {
	public static void main(String argv[]) {
		System.out.print("Uno"+"Dos"+"Tres"+"Cuatro");
	}
}
