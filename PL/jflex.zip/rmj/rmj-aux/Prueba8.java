class Prueba8 {
	public static void main(String argv[]) {
		String var1 = "Uno"+"Dos"+"Tres";
		System.out.println(var1);
	}
}
