class Prueba9_rmj {
	public static void main(String argv[]) {
		 
		System.out.println("UnoDosTres");
		 
		System.out.println("UnoDosUnoDosTresUnoDosCuatro");
	}
}
